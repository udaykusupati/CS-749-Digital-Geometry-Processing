from subprocess import call
import numpy as np
import math
import matplotlib.pyplot as plt

def l2(v1,v2):
    listv1=v1.split(' ')
    listv2=v2.split(' ')
    tsum=0
    for p in range(36):
        sum1=0
        for i in range(20):
            sum1+=(float(listv1[p*20+i])-float(listv2[p*20+i]))*(float(listv1[p*20+i])-float(listv2[p*20+i]))
        sum1=float(math.sqrt(sum1))
        tsum += sum1
    return tsum


ids = []

mapc = {}
#num = False
# size = 0
# cat = ""
# with open("b.txt") as file1:
#     for line in file1:
#         line = line.strip().split()
#         #print(line)
#         if not num :
#         	if int(line[2]) != 0:
#         		num = True
#         		size = int(line[2])
#         		cat = line[0]
#         else:
#         	ind = int(line[0])
#         	mapc[ind] = cat
#         	ids.append(ind)
#         	size -= 1
#         	if size==0:
#         		num = False
# print(len(mapc))
# print(len(ids))
ids.append(87)
ids.append(90)
ids.append(110)
ids.append(111)
ids.append(277)
ids.append(279)
ids.append(291)
ids.append(293)
ids.append(295)
ids.append(297)
mapc[87] = "dog"
mapc[90] = "dog"
mapc[110] = "rabbit"
mapc[111] = "rabbit"
mapc[277] = "turtle"
mapc[279] = "turtle"
mapc[291] = "face"
mapc[293] = "face"
mapc[295] = "face"
mapc[297] = "face"
ids.sort()


# for id in ids:
#  	call(["./meshdesc", "benchmark/db/"+str(id/100)+"/m"+str(id)+"/m"+str(id)+".off", "15"])

ratios = []
with open("hist.txt") as file:
    for line in file:
        line = line.strip("\n")
        ratios.append(line)

#print(len(ratios))

# dist = []

# for i in range(len(ids)):
# 	temp = []
# 	for j in range(len(ids)):
# 		l2d = l2(ratios[i],ratios[j])
# 		if l2d<0:
# 			l2d = -l2d
# 		temp.append(l2d)
# 	dist.append(temp)
# print(dist)

hist = []
for i in range(len(ratios)):
    v=[float(j) for j in ratios[i].split(' ')]
    hist.append(v)
print(hist)

# plt.plot(hist[0],'r-')
# plt.plot(hist[1],'g-')
plt.plot(hist[0],'r-')
plt.plot(hist[1],'g-')
plt.ylabel('some numbers')
plt.show()

# K = [1,5,10,20,50]
# top1 = []
# top5 = []
# top10 = []
# top20 = []
# top50 = []

# for k in K:
# 	for i in range(len(dist)):
# 		A = np.array(dist[i])
# 		indices = np.argpartition(A,k+1)
# 		temp = indices[1:k+1]
# 		if k ==1:
# 			top1.append(temp)
# 		if k ==5:
# 			top5.append(temp)
# 		if k ==10:
# 			top10.append(temp)
# 		if k ==20:
# 			top20.append(temp)
# 		if k ==50:
# 			top50.append(temp)

# print(len(top1[0]))
# print(len(top5[0]))
# print(len(top10[0]))
# print(len(top20[0]))
# print(len(top50[0]))
# prec = []
# recall = [] 

# for i in range(len(top1)):
#     #print(mapc[ids[i]])
# 	#print(mapc[top1[i][0]])
#     count = 0

#     for j in range(len(top1[i])):

#         if mapc[ids[i]] == mapc[ids[top1[i][j]]]:
#             count += 1
#     prec.append(float(count)/len(top1[i]))
#     total = 0
#     for k in range(len(ids)):
#         if mapc[ids[i]] == mapc[ids[k]] and i != k:
#             total += 1
#     recall.append(float(count)/total)
# print("prec")
# avg = float(sum(prec))/len(prec)
# print(avg)
# print("recall")
# avgr = float(sum(recall))/len(recall)
# print(avgr)

# prec = []
# recall = [] 
# total = 0
# for i in range(len(top5)):
#     #print(mapc[ids[i]])
#     #print(mapc[top1[i][0]])
#     count = 0
#     for j in range(len(top5[i])):

#         if mapc[ids[i]] == mapc[ids[top5[i][j]]]:
#             count += 1
#     prec.append(float(count)/len(top5[i]))

#     for k in range(len(ids)):
#         if mapc[id[i]] == mapc[id[k]] and i != k:
#             total += 1
#     recall.append(float(count)/len(total))
# print("top5")
# print("prec")
# avg = float(sum(prec))/len(prec)
# print(avg)
# print("recall")
# avgr = float(sum(recall))/len(recall)
# print(avgr)

# prec = []
# recall = [] 
# total = 0
# for i in range(len(top10)):
#     #print(mapc[ids[i]])
#     #print(mapc[top1[i][0]])
#     count = 0
#     for j in range(len(top10[i])):

#         if mapc[ids[i]] == mapc[ids[top10[i][j]]]:
#             count += 1
#     prec.append(float(count)/len(top10[i]))

#     for k in range(len(ids)):
#         if mapc[id[i]] == mapc[id[k]] and i != k:
#             total += 1
#     recall.append(float(count)/len(total))
# print("top10")
# print("prec")
# avg = float(sum(prec))/len(prec)
# print(avg)
# print("recall")
# avgr = float(sum(recall))/len(recall)
# print(avgr)

# prec = []
# recall = [] 
# total = 0
# for i in range(len(top20)):
#     #print(mapc[ids[i]])
#     #print(mapc[top1[i][0]])
#     count = 0
#     for j in range(len(top20[i])):

#         if mapc[ids[i]] == mapc[ids[top20[i][j]]]:
#             count += 1
#     prec.append(float(count)/len(top20[i]))

#     for k in range(len(ids)):
#         if mapc[id[i]] == mapc[id[k]] and i != k:
#             total += 1
#     recall.append(float(count)/len(total))
# print("top20")
# print("prec")
# avg = float(sum(prec))/len(prec)
# print(avg)
# print("recall")
# avgr = float(sum(recall))/len(recall)
# print(avgr)

# prec = []
# recall = []
# total = 0 
# for i in range(len(top50)):
#     #print(mapc[ids[i]])
#     #print(mapc[top1[i][0]])
#     count = 0
#     for j in range(len(top50[i])):

#         if mapc[ids[i]] == mapc[ids[top50[i][j]]]:
#             count += 1
#     prec.append(float(count)/len(top50[i]))

#     for k in range(len(ids)):
#         if mapc[id[i]] == mapc[id[k]] and i != k:
#             total += 1
#     recall.append(float(count)/len(total))

# print("top50")
# print("prec")
# avg = float(sum(prec))/len(prec)
# print(avg)
# print("recall")
# avgr = float(sum(recall))/len(recall)
# print(avgr)
