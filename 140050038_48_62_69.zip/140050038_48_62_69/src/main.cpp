#include "Eigen/SparseCore"
#include "SymGEigsSolver.h"
#include "MatOp/SparseSymMatProd.h"
#include "MatOp/SparseRegularInverse.h"
#include "Mesh.hpp"
#include "Viewer.hpp"
#include "DGP/Colors.hpp"
#include <algorithm>
#include <cstdlib>
#include <vector>

using namespace Spectra;
int
usage(int argc, char * argv[])
{
  DGP_CONSOLE << "";
  DGP_CONSOLE << "Usage: " << argv[0] << " <mesh> <#eigen_values>[seg <#segments>] [hist <#points> <#bins>]";
  DGP_CONSOLE << "";

  return -1;
}
double
distance(std::vector<double> v)
{
  double len = 0.0;
  for (size_t p = 0; p < v.size(); ++p)
  {
    len += v[p]*v[p];
  }
  len = sqrt(len);
  return len;
}

double
distance_between_points(std::vector<double> v1,std::vector<double> v2)
{
  std::vector<double> v;
  double len = 0.0;

  for (size_t p = 0; p < v1.size(); ++p)
  {
    v.push_back(v1[p]-v2[p]);
  }

  for (size_t p = 0; p < v.size(); ++p)
  {
    len += v[p]*v[p];
  }
  len = sqrt(len);
  return len;
}

double
samplePoints(Mesh const & mesh, size_t num_points,std::vector<std::vector<double>> G,  std::vector<std::vector<double>> & points,int m)
{
  std::vector<std::vector<double>> partition;
  partition.resize(m);
  points.resize(m);

  double maxradius = 0.0;

  for (size_t i = 0; i < G.size(); ++i)
  {
    double dist = distance(G[i]);
    if(maxradius < dist)
    {
      maxradius = dist;
    }
  }

  for (size_t i = 0; i < G.size(); ++i)
  {
    double dist = distance(G[i]);
    int t = m*dist/maxradius;
    if(t==m){t=m-1;}
    partition[t].push_back(i);
  }

  for (int i = 0; i < m; ++i)
  {
    if(partition[i].size() != 0)
    {
      for (size_t j = 0; j < num_points; ++j)
      {
        int r = rand() % partition[i].size();
        points[i].push_back(partition[i][r]);
      }      
    }
  }
  return maxradius;

}

void
computeD2(Mesh const & mesh, size_t num_points, size_t num_bins,std::vector<std::vector<double>> G ,std::vector<double> & histogram,std::vector<std::vector<double>> & points,std::vector<double> part, int x, int y)
{
  histogram.resize(num_bins);
  fill(histogram.begin(), histogram.end(), 0.0);

  int total = 0;
  for (size_t i = 0; i < points[x].size(); ++i)
  {
    for (size_t j = 0; j < points[y].size(); ++j)
    {
      total += 1;
      double dist = distance_between_points(G[points[x][i]], G[points[y][j]]);
      for (size_t k = 0; k < num_bins; ++k)
      {               
        if(dist<=part[k])
        {
          histogram[k] += 1;
          break;
        }
      }
    }
  }
  for (size_t i = 0; i < num_bins; ++i)
  {
    if(total !=0 )
    {
      histogram[i] = histogram[i] / total;
    }    
  }
}

void
computeG2(Mesh const & mesh, size_t num_points, size_t num_bins, std::vector<std::vector<double>> G, std::vector<std::vector<double>> & histograms,int m)
{
  std::vector<std::vector<double>> points;
  double maxlength = samplePoints(mesh,num_points,G,points,m);
  std::vector<double> part;
  for (size_t i = 1; i <= num_bins; ++i)
  {
    double temp = maxlength * i;
    temp = temp / num_bins;
    part.push_back(temp);
  }
  std::vector<double> histogram;
  histogram.resize(num_bins);
  
  for(int i = 0; i < m; i++)
  {
    for (int j = i; j < m; ++j)
    {
      computeD2(mesh, num_points, num_bins, G, histogram, points, part, i, j);
      histograms.push_back(histogram);
    }
  }
}

std::vector<double> gps(MeshVertex* v, Eigen::MatrixXd &evectors,Eigen::VectorXd &evalues)
{
  std::vector<double> result;
  for(int i=0;i<evectors.cols();i++)
  {
    if(evalues(i)<0.00001)continue;
    result.push_back(evectors(v->getId(),i)*1.0/std::sqrt(evalues(i)));
  }
  return result;
}

double distance(std::vector<double> a,std::vector<double> b)
{
  double result=0;
  for(uint i=0;i<a.size();i++)
  {
    result+=(a[i]-b[i])*(a[i]-b[i]);
  }
  return std::sqrt(result);
}
std::vector<double> mean(std::vector<MeshVertex* > cluster,  Eigen::MatrixXd &evectors,Eigen::VectorXd &evalues)
{
  std::vector<std::vector<double> > a;
  for(uint i=0;i<cluster.size();i++)
  {
    a.push_back(gps(cluster[i], evectors,evalues));
  }
  std::vector<double> result;
  for(uint dim=0;dim<a[0].size();dim++)
  {
    double sum=0;
    for(uint i=0;i<a.size();i++)
    { 
      sum+=a[i][dim];
    }
    result.push_back(sum/a.size());
  }
  return result;
}
void segmentation(Mesh &mesh,uint &k, Eigen::MatrixXd &evectors,Eigen::VectorXd &evalues)//k-means clustering in GPS space
{
  std::vector<std::vector<double>> means;
  std::vector<std::vector<MeshVertex*> > clusters(k);
  
  std::vector<std::vector<double> > G;
  for(auto it=mesh.verticesBegin();it!=mesh.verticesEnd();++it)
  {
    G.push_back(gps(&(*it),evectors,evalues));
  }
  std::srand(1500);
  for(uint s=0;s<k;s++)
  {
    int index=std::rand()%G.size();
    means.push_back(G[index]);
  }
  bool converged=false;

  while(converged==false)
  {
    converged=true;
    for(uint c=0;c<k;c++)
    {
      clusters[c].clear();
    }
    for(auto vit=mesh.verticesBegin();vit!=mesh.verticesEnd();++vit)
    {
      int minm=0; 
      std::vector<double> temp=means[0];
      double mindistance=distance(gps(&(*vit),evectors,evalues),temp);
      for(uint m=0;m<means.size();m++)
      {
        temp=means[m];
        double currdistance=distance(gps(&(*vit),evectors,evalues),temp);
        if(currdistance<mindistance)
        {
          mindistance=currdistance;
          minm=m;
        }
      }
      if(vit->cluster_id!=minm)
      {
        vit->cluster_id=minm;
        converged=false;        
      }
      clusters[vit->cluster_id].push_back(&(*vit));
    }
    for(uint i=0;i<k;i++)
    {
      if(clusters[i].size()>0)means[i]=mean(clusters[i],evectors,evalues);
    }
  }
  return; 
}
void setcolor(Mesh &mesh,uint &k)
{
  for(auto vit=mesh.verticesBegin();vit!=mesh.verticesEnd();++vit)
  {
    int id=vit->cluster_id;
    switch(id)
    {
      case 0:
        vit->setColor(ColorRGBA(1,0,0,1.0));break;
      case 1:
        vit->setColor(ColorRGBA(0,1,0,1.0));break;
      case 2:
        vit->setColor(ColorRGBA(0,0,1,1.0));break;
      case 3:
        vit->setColor(ColorRGBA(1,1,1,1.0));break;
      case 4:
        vit->setColor(ColorRGBA(1,1,0,1.0));break;
      case 5:
        vit->setColor(ColorRGBA(0,1,1,1.0));break;
      case 6:
        vit->setColor(ColorRGBA(1,0,1,1.0));break;
      case 7:
        vit->setColor(ColorRGBA(1,0.5,1,1.0));break;
      case 8:
        vit->setColor(ColorRGBA(0.5,1,1,1.0));break;
      case 9:
        vit->setColor(ColorRGBA(1,1,0.5,1.0));break;
      case 10:
        vit->setColor(ColorRGBA(1,0.5,0.5,1.0));break;
      case 11:
      vit->setColor(ColorRGBA(0.5,0.5,1,1.0));break;
      case 12:
      vit->setColor(ColorRGBA(0.5,1,0.5,1.0));break;
    }
    
  }
}

int
main(int argc, char * argv[])
{
  if (argc < 4)
    return usage(argc, argv);
  
  std::string in_path = argv[1];
  Mesh mesh;
  if (!mesh.load(in_path))
    return -1;

  DGP_CONSOLE << "Read mesh '" << mesh.getName() << "' with " << mesh.numVertices() << " vertices, " << mesh.numEdges()
             << " edges and " << mesh.numFaces() << " faces from " << in_path;
  
  Eigen::SparseMatrix<double> M;
  Eigen::SparseMatrix<double> S;
  
  mesh.computeMandS(M,S);
  
  SparseSymMatProd<double> opM(M);
  SparseRegularInverse<double> opS(S);
  
  int nev=atoi(argv[2]);
  
  SymGEigsSolver< double, SMALLEST_ALGE, SparseSymMatProd<double> ,SparseRegularInverse<double> ,GEIGS_REGULAR_INVERSE > eigs(&opM, &opS, nev,1+nev*2 );

  eigs.init();
  eigs.compute();
  
  Eigen::VectorXd evalues;
  if(eigs.info() == SUCCESSFUL)
      evalues = eigs.eigenvalues();

  Eigen::MatrixXd evectors=eigs.eigenvectors();

  auto product=evectors.transpose()*S*evectors;
  for(uint i=0;i<evectors.cols();i++)
  {
    double n =product(i,i);
    for(uint j=0;j<evectors.rows();j++)
    {
      evectors(j,i)=evectors(j,i)/n;
    }
  }
  std::string input=argv[3];
  if(input=="hist")
  {
    std::vector<std::vector<double> > G;
    for(auto it=mesh.verticesBegin();it!=mesh.verticesEnd();++it)
    {
      G.push_back(gps(&(*it),evectors,evalues));
    }

    std::vector<std::vector<double>> histograms;
    computeG2(mesh, atoi(argv[4]),atoi(argv[5]),G, histograms, 1);
    for (size_t i = 0; i < histograms.size(); ++i)
    {
      for (size_t j = 0; j < histograms[i].size(); ++j)
      {
        if (j > 0 || i!=0) std::cout << ' ';
        std::cout << histograms[i][j];     
      }
    }
    std::cout << std::endl;
  }
  else if(input=="seg")
  {
    uint k=atoi(argv[4]);
    segmentation(mesh,k,evectors,evalues);
    setcolor(mesh,k);
    Viewer viewer;
    viewer.setObject(&mesh);
    viewer.launch(argc, argv);
  }
  else
  {
    return usage(argc, argv);
  }
  return 0;
}
