#ifndef __A1_Common_hpp__
#define __A1_Common_hpp__

#include "DGP/Common.hpp"

using namespace DGP;

#endif
