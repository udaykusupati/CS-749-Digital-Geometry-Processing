#include "PointKDTree.hpp"

PointKDTree::Node::~Node()
{
  delete lo;
  delete hi;
}

PointKDTree::PointKDTree(std::vector<Point> const & points)
: root(NULL)
{
  build(points);
}

PointKDTree::PointKDTree(std::vector<Point *> const & points)
: root(NULL)
{
  build(points);
}

// PointKDTree::PointKDTree(PointCloud const & pcloud)
// : root(NULL)
// {
//   build(pcloud.getPoints());
// }

void
PointKDTree::build(std::vector<Point> const & points)
{
  std::vector<Point *> pp(points.size());
  for (size_t i = 0; i < pp.size(); ++i)
    pp[i] = const_cast<Point *>(&points[i]);  // removing the const is not the greatest thing to do, be careful...

  build(pp);
}

void
PointKDTree::build(std::vector<Point *> const & points)
{
  // TODO

  static size_t const MAX_POINTS_PER_LEAF = 5;

  // A kd-tree is just a binary search tree, and is constructed in a near-identical way.
  //
  // - Initially assign (pointers to) all points to the root node.
  // - Recursively subdivide the points, splitting the parent box in half along the longest axis and creating two child nodes
  //   for each split. Stop when number of points in node <= MAX_POINTS_PER_LEAF.
  // - Don't forget to save space by clearing the arrays of points in internal nodes. Only the leaves need to store references
  //   to points.
//DGP_CONSOLE<<points.size()<<"\n";
root=new Node;
  for(unsigned int i=0;i<points.size();i++)
  {
    
    root->points.push_back(points[i]);

    root->bbox.merge(points[i]->getPosition());
  }
  //DGP_CONSOLE<<root->points.size()<<"size\n";

  split(root);
  return;
}

void PointKDTree::split(Node* n)
{
  static size_t const MAX_POINTS_PER_LEAF = 5;
  if(n->points.size()<=MAX_POINTS_PER_LEAF)
  {
    //DGP_CONSOLE<<n->points.size()<<"term\n";
    return;
  }
  else
  {
    //DGP_CONSOLE<<n->points.size()<<"nonterm  ";
    Vector3 low=n->bbox.getLow();
    Vector3 high=n->bbox.getHigh();
    int axis=0;
    if((high.x()-low.x()<high.y()-low.y())&&(high.z()-low.z()<high.y()-low.y()))axis=1;
    else
    {
      if(high.x()-low.x()<high.z()-low.z())axis=2;
      else axis=0;
    }
    double mid=high[axis]/2-low[axis]/2;
    //DGP_CONSOLE<<mid<<"\n";
    n->lo=new Node;
    n->hi=new Node;
    for(unsigned int i=0;i<n->points.size();i++)
    {
      /*if(n->points.size()==11){
        DGP_CONSOLE<<n->points[i]->getPosition()[axis]<<"\n";
      }*/
      if(n->points[i]->getPosition()[axis]<=low[axis]+mid)
      {
        n->lo->points.push_back(n->points[i]);
        n->lo->bbox.merge(n->points[i]->getPosition());
      }
      else
      {
        n->hi->points.push_back(n->points[i]);
        n->hi->bbox.merge(n->points[i]->getPosition());
      }
    }
    n->points.clear();
    split(n->lo);
    split(n->hi);
    return;
  }
}
