EC2 and EC1 are done.
EC1:
candidate planes are eliminated if any of the candidate point's normals are too diverged from the plane's normal.
EC2:
For every point on a slab, k nearest neighbors are seen and depending on their normals' directions, we keep all the points or remove our point.
At the end for each slab we add randomly one third of removed points.
Also edges are detected by checking for points lying in intersection of slabs taken with margins i.e the closest distance of a point in slab to a corner.