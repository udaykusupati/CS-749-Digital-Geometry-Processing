(a)EC1 done.
	I have used a multiset as a priority queue. The remove time is logarithmic. Every time i collapse an edge I remove it from the queue and in merge also when i remove an edge i remove it from queue and also when updating the errors of edges i remove them update errors and insert back. So every iteration takes logarithmic time.
(b)EC2 done.
	I have declared a class vertexPair which stores a pair of vertices. Simultaneously along with edges i store the vertexpairs within threshold and i wrote a function to collapse vertexpairs.
	