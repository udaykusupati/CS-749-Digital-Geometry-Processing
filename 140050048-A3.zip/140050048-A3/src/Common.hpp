#ifndef __A3_Common_hpp__
#define __A3_Common_hpp__

#include "DGP/Common.hpp"

using namespace DGP;

#endif
