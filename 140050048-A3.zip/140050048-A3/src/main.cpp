#include "Mesh.hpp"
#include <algorithm>
#include <cstdlib>
#include <vector>
#include <ctime>
#include "DGP/Triangle3.hpp"
#include "DGP/Polygon3.hpp"
int
usage(int argc, char * argv[])
{
  DGP_CONSOLE << "";
  DGP_CONSOLE << "Usage: " << argv[0] << " <mesh> [vol2bbox] [d2 <#points> <#bins>]";
  DGP_CONSOLE << "";

  return -1;
}

/** Compute the volume enclosed by the mesh. An approximation is ok as long as it is not too coarse. */
double
computeVolume(Mesh const & mesh)
{
  // TODO
  /*Vector3 point(0.0,0.0,0.0);
  for(auto it= mesh.verticesBegin();it!=mesh.verticesEnd();++it)
  {
    point=point+it->getPosition();
  }
  point=point/mesh.numVertices();
  double volume=0;*/
  double vol=0;
  for(auto it=mesh.facesBegin();it!=mesh.facesEnd();++it)
  {
    Polygon3 polygon;
    for(auto vit=it->verticesBegin();vit!=it->verticesEnd();++vit)
    {
    	polygon.addVertex((*vit)->getPosition());
    }
    Vector3 o=(*(it->verticesBegin()))->getPosition();
    //double signedHeight=-1*(point-o).dot(it->getNormal().unit());
    double s=o.dot(it->getNormal().unit());
    double area=polygon.area();
    //volume=volume+double(1.0/3)*area*signedHeight;
    vol+=double(1.0/3)*area*s;

  }
  return fabs(vol);
  return -1;
}

/** Compute the ratio of the volume of the shape to the volume of its bounding box. */
double
computeVolumeToBBoxRatio(Mesh const & mesh)
{
  // TODO: You only need to complete ONE of the compute*() functions for the basic portion of the assignment.
  // (1) Compute the (approximate) volume enclosed by the mesh using computeVolume() (this is the hard bit)
  double volume=computeVolume(mesh);
  // (2) Compute the bbox volume of the mesh  (this is the easy bit -- it's a one-liner)
  double bVolume=mesh.getAABB().volume();
  // (3) Return the ratio
  return volume/bVolume;

  return -1;
}

/**
 * Select \a num_points points from the surface of a mesh, distributed i.i.d. and uniformly by area. You do NOT need to
 * implement something fancy like furthest point sampling, just repeat the basic step of:
 *   - pick a face with probability proportional to its area
 *   - pick a random point uniformly distributed across the face
 */
void
samplePoints(Mesh const & mesh, size_t num_points, std::vector<Vector3> & points)
{
  // TODO
	std::vector<LocalTriangle3> triangles;
  for(auto it=mesh.facesBegin();it!=mesh.facesEnd();++it)
  {
	  Polygon3 polygon;
      for(auto vit=it->verticesBegin();vit!=it->verticesEnd();++vit)
      {
        polygon.addVertex((*vit)->getPosition());
      }
      std::vector<long> tri_indices;
      int numt=polygon.triangulate(tri_indices);
      for(int j=0;j<numt;j++)
      {
        LocalTriangle3 triangle(polygon.getVertex(tri_indices[3*j]).position,polygon.getVertex(tri_indices[3*j+1]).position,polygon.getVertex(tri_indices[3*j+2]).position);
        triangles.push_back(triangle);
      }
  }
  std::vector<double> probs;
  double sum=0;
  for(unsigned int i=0;i<triangles.size();i++)
  {
  	double area=0;
  	Vector3 v0=triangles[i].getVertex(0);
  	Vector3 v1=triangles[i].getVertex(1);
  	Vector3 v2=triangles[i].getVertex(2);
  	area=(v1-v0).cross(v2-v0).length()/2.0;
  	sum+=area;
  	probs.push_back(area);
  }
  for(unsigned int i=0;i<triangles.size();i++)probs[i]=probs[i]/sum;

  srand(time(NULL));
  for(unsigned int p=0;p<num_points;p++)
  {
	  float random = ((float) rand()) / (float) RAND_MAX;
	  int index=0;
	  for(unsigned int i=0;i<triangles.size();i++)
	  {
	  	random-=probs[i];
	  	if(random<0)
	  	{
	  		index=i;break;
	  	}
	  }
	  points.push_back(triangles[index].randomPoint());
  }
}

/**
 * Compute the Euclidean D2 descriptor: a histogram of all pairwise Euclidean distances between num_points points on the mesh,
 * distributed uniformly and identically by area. The histogram should divide the range of distances between 0 and the bounding
 * box diagonal of the mesh into num_bins uniformly spaced bins. Normalize the histogram by dividing by the total number of
 * points.
 */
void
computeD2(Mesh const & mesh, size_t num_points, size_t num_bins, std::vector<double> & histogram)
{
  // TODO: You only need to complete ONE of the compute*() functions for the basic portion of the assignment.
  histogram.resize(num_bins);
  fill(histogram.begin(), histogram.end(), 0.0);

  // (1) Sample num_points points using samplePoints()
  std::vector<Vector3> points;
  samplePoints(mesh,num_points,points);
  // (2) Compute the bounding box diagonal, which is the maximum value that can be binned in the histogram
  double maxval=(mesh.getAABB().getHigh()-mesh.getAABB().getLow()).length();
  // (3) Compute all pairwise L2 distances between distinct points (i.e. ignore the zero distance between a point and itself)
  int count=0;
  for(unsigned int i=0;i<points.size();i++)
  {
  	for(unsigned int j=i+1;j<points.size();j++)
  	{
  		double length=(points[i]-points[j]).length();
  		int b=0;
  		while(length>b*maxval/double(num_bins))b++;
  		histogram[b]++;
      count++;
  	}
  }
  for(unsigned int i=0;i<histogram.size();i++)histogram[i]/=double(count);
  //     and bin them in the histogram
}

int
main(int argc, char * argv[])
{
  if (argc < 2)
    return usage(argc, argv);

  std::string in_path = argv[1];

  Mesh mesh;
  if (!mesh.load(in_path))
    return -1;

  /*DGP_CONSOLE << "Read mesh '" << mesh.getName() << "' with " << mesh.numVertices() << " vertices, " << mesh.numEdges()
              << " edges and " << mesh.numFaces() << " faces from " << in_path;
*/
  std::vector<double> feature_vector;
  for (int i = 2; i < argc; ++i)
  {
    std::string feat_type = argv[i];
    if (feat_type == "vol2bbox")
      feature_vector.push_back(computeVolumeToBBoxRatio(mesh));
    else if (feat_type == "d2")
    {
      if (i > argc - 3)
        return usage(argc, argv);

      int num_points = atoi(argv[++i]);
      int num_bins = atoi(argv[++i]);
      if (num_points < 1 || num_bins < 1)
      {
        std::cerr << "Invalid D2 parameters" << std::endl;
        return -1;
      }

      std::vector<double> d2;
      computeD2(mesh, (size_t)num_points, (size_t)num_bins, d2);
      feature_vector.insert(feature_vector.end(), d2.begin(), d2.end());
    }
  }
  for (size_t i = 0; i < feature_vector.size(); ++i)
  {
    if (i > 0) std::cout << ' ';
    std::cout << feature_vector[i];
  }

  std::cout << std::endl;

  return 0;
}
